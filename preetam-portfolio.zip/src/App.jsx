import { useState } from 'react'
import {
  ArrowDownRight, ArrowUpRight, Github, Linkedin, Mail, Menu, X,
  Code2, Layers3, Smartphone, Sparkles, ExternalLink, HeartPulse,
  Braces, Database, Globe2, Terminal, MoveUpRight
} from 'lucide-react'

const projects = [
  {
    number: '01',
    name: 'BloodConnect',
    type: 'HEALTHCARE · FULL-STACK CONCEPT',
    description: 'A donor discovery and emergency blood request platform designed to help connect patients, donors, hospitals and blood banks.',
    tags: ['React', 'Node.js', 'MongoDB', 'Express'],
    className: 'project-red',
    icon: HeartPulse,
    link: '#contact',
    linkLabel: 'Discuss project',
  },
  {
    number: '02',
    name: 'Your next project',
    type: 'WEB APPLICATION',
    description: 'Replace this card with another project. Explain the problem, your approach, and the outcome in two or three concise sentences.',
    tags: ['React', 'UI Design', 'API'],
    className: 'project-blue',
    icon: Layers3,
    link: 'https://github.com/',
    linkLabel: 'Add project link',
  },
  {
    number: '03',
    name: 'A small experiment',
    type: 'EXPERIMENT · INTERACTION',
    description: 'A space for a creative experiment, a useful tool, or a small build that shows how you think and what you enjoy making.',
    tags: ['JavaScript', 'CSS', 'Creative code'],
    className: 'project-violet',
    icon: Sparkles,
    link: 'https://github.com/',
    linkLabel: 'Add project link',
  },
]

const skills = [
  { label: 'Frontend', detail: 'Interfaces & experiences', icon: Code2, items: ['React', 'JavaScript', 'HTML & CSS', 'Tailwind CSS'] },
  { label: 'Backend', detail: 'APIs & application logic', icon: Braces, items: ['Node.js', 'Express', 'REST APIs'] },
  { label: 'Data', detail: 'Storage & modeling', icon: Database, items: ['MongoDB', 'Mongoose'] },
  { label: 'Workflow', detail: 'Build, ship & iterate', icon: Terminal, items: ['Git & GitHub', 'Vite', 'Vercel'] },
]

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const closeMenu = () => setMenuOpen(false)

  return (
    <div className="site-shell">
      <div className="noise" aria-hidden="true" />
      <header className="topbar">
        <a className="brand" href="#home" onClick={closeMenu} aria-label="Preetam home">
          <span className="brand-mark">P<span>.</span></span>
          <span>PREETAM<span className="brand-muted"> / PORTFOLIO</span></span>
        </a>
        <button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">
          {menuOpen ? <X size={21} /> : <Menu size={21} />}
        </button>
        <nav className={menuOpen ? 'nav-links open' : 'nav-links'}>
          <a href="#work" onClick={closeMenu}>Work</a>
          <a href="#about" onClick={closeMenu}>About</a>
          <a href="#skills" onClick={closeMenu}>Skills</a>
          <a href="#contact" onClick={closeMenu}>Contact</a>
          <a className="nav-cta" href="#contact" onClick={closeMenu}>Let's talk <ArrowUpRight size={15} /></a>
        </nav>
      </header>

      <main>
        <section className="hero section-wrap" id="home">
          <div className="hero-copy">
            <div className="eyebrow"><span className="status-dot" /> AVAILABLE FOR OPPORTUNITIES <span className="eyebrow-line" /></div>
            <h1>Building digital<br />things with <span className="accent-word">purpose.</span></h1>
            <p className="hero-intro">Hey, I'm <strong>Preetam</strong> — a developer who enjoys turning thoughtful ideas into useful, well-crafted digital experiences.</p>
            <div className="hero-actions">
              <a className="button button-primary" href="#work">Explore my work <ArrowUpRight size={17} /></a>
              <a className="text-link" href="#contact">Get in touch <ArrowDownRight size={16} /></a>
            </div>
            <div className="hero-meta">
              <span><Globe2 size={14} /> Based in India</span>
              <span className="meta-separator">·</span>
              <span>Open to learning & building</span>
            </div>
          </div>
          <div className="hero-art" aria-label="Abstract portfolio illustration">
            <div className="art-orbit orbit-one" />
            <div className="art-orbit orbit-two" />
            <div className="art-grid" />
            <div className="art-core">
              <div className="core-top"><span>CREATIVE</span><span>001 / 026</span></div>
              <div className="core-symbol">P<span>↗</span></div>
              <div className="core-bottom"><span>IDEA → INTERFACE</span><span className="core-live"><i /> LIVE</span></div>
            </div>
            <div className="float-chip chip-code"><Code2 size={15} /> clean code</div>
            <div className="float-chip chip-build"><Sparkles size={15} /> curious mind</div>
            <div className="art-index">FIG. 01 — THE CREATIVE PROCESS</div>
          </div>
          <a className="scroll-cue" href="#work"><span /> SCROLL TO EXPLORE</a>
        </section>

        <section className="work-section section-wrap" id="work">
          <div className="section-heading">
            <div><div className="eyebrow">SELECTED PROJECTS / 2026</div><h2>Things I've <span className="muted-heading">worked on.</span></h2></div>
            <p>A selection of builds, ideas and experiments. <br />More stories coming as I keep creating.</p>
          </div>
          <div className="project-list">
            {projects.map((project) => {
              const Icon = project.icon
              return <article className={`project-card ${project.className}`} key={project.number}>
                <div className="project-visual">
                  <div className="visual-top"><span>PROJECT / {project.number}</span><span>✳</span></div>
                  <div className="visual-icon"><Icon size={47} strokeWidth={1.25} /></div>
                  <div className="visual-bottom"><span>DESIGN × DEVELOPMENT</span><span>2026</span></div>
                </div>
                <div className="project-info">
                  <div className="project-type">{project.type}</div>
                  <h3>{project.name}</h3>
                  <p>{project.description}</p>
                  <div className="tag-row">{project.tags.map(tag => <span className="tag" key={tag}>{tag}</span>)}</div>
                  <a className="project-link" href={project.link} target={project.link.startsWith('http') ? '_blank' : undefined} rel="noreferrer">{project.linkLabel} <MoveUpRight size={16} /></a>
                </div>
              </article>
            })}
          </div>
        </section>

        <section className="about-section section-wrap" id="about">
          <div className="about-left">
            <div className="eyebrow">A LITTLE ABOUT ME</div>
            <h2>Curiosity first.<br /><span className="muted-heading">Craft always.</span></h2>
            <div className="about-stamp">MAKE<br />IT<br /><span>MATTER.</span></div>
          </div>
          <div className="about-right">
            <p className="about-lead">I believe the best digital experiences sit at the intersection of clear thinking, useful technology and considered design.</p>
            <p className="about-body">I'm growing my skills by building projects, exploring new tools and learning how to turn real-world problems into simple, accessible products. I care about the details — from the first sketch to the final interaction.</p>
            <div className="about-facts">
              <div><span className="fact-number">01</span><span>Learn by building</span></div>
              <div><span className="fact-number">02</span><span>Keep it human</span></div>
              <div><span className="fact-number">03</span><span>Improve every iteration</span></div>
            </div>
          </div>
        </section>

        <section className="skills-section section-wrap" id="skills">
          <div className="section-heading">
            <div><div className="eyebrow">TOOLS OF THE TRADE</div><h2>My current <span className="muted-heading">toolkit.</span></h2></div>
            <p>Technologies I'm exploring and using<br />to bring ideas to life.</p>
          </div>
          <div className="skills-grid">
            {skills.map((skill, index) => {
              const Icon = skill.icon
              return <div className="skill-card" key={skill.label}>
                <div className="skill-card-top"><span>0{index + 1}</span><Icon size={20} /></div>
                <h3>{skill.label}</h3><p>{skill.detail}</p>
                <div className="skill-items">{skill.items.map(item => <span key={item}>{item}</span>)}</div>
              </div>
            })}
          </div>
        </section>

        <section className="contact-section section-wrap" id="contact">
          <div className="contact-panel">
            <div className="contact-kicker"><span className="status-dot" /> THE NEXT GOOD THING STARTS WITH A CONVERSATION</div>
            <h2>Have an idea?<br /><span>Let's make it real.</span></h2>
            <p>Have a project in mind, an opportunity, or just want to say hello? My inbox is open.</p>
            <a className="button button-light" href="mailto:your.email@example.com">Say hello <ArrowUpRight size={17} /></a>
            <div className="contact-decoration">LET'S<br />BUILD<span>↗</span></div>
          </div>
        </section>
      </main>

      <footer className="footer section-wrap">
        <a className="brand footer-brand" href="#home"><span className="brand-mark">P<span>.</span></span><span>PREETAM<span className="brand-muted"> / PORTFOLIO</span></span></a>
        <span className="footer-note">Designed & built with curiosity. © 2026</span>
        <div className="social-links">
          <a href="https://github.com/" target="_blank" rel="noreferrer" aria-label="GitHub"><Github size={17} /></a>
          <a href="https://linkedin.com/" target="_blank" rel="noreferrer" aria-label="LinkedIn"><Linkedin size={17} /></a>
          <a href="mailto:your.email@example.com" aria-label="Email"><Mail size={17} /></a>
        </div>
      </footer>
    </div>
  )
}

export default App

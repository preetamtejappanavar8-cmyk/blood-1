# Preetam — Developer Portfolio

A responsive React + Vite portfolio starter, ready for GitHub and Vercel. The featured BloodConnect project is based on the project brief supplied with this request.

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually http://localhost:5173).

## Build

```bash
npm run build
npm run preview
```

## Personalize before publishing

Search `src/App.jsx` for `EDIT ME` and replace:
- Your role, short bio, location and availability
- Email and social profile URLs
- Project links and project descriptions
- Skills to match your actual experience

The BloodConnect entry is presented as a project concept/case study. Update its status and links to reflect the actual implementation before publishing. Do not claim production deployment, users, or metrics unless verified.

## Push to GitHub

Create an empty repository on GitHub, then run:

```bash
git init
git add .
git commit -m "Build portfolio website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

## Deploy on Vercel

1. Sign in at https://vercel.com and choose **Add New → Project**.
2. Import your GitHub repository.
3. Vercel should detect Vite automatically.
4. Build command: `npm run build`
5. Output directory: `dist`
6. Select **Deploy**.

Every push to the connected branch will trigger a new deployment.

## Notes

- This is a frontend portfolio. It does not require a database or environment variables.
- The contact link opens the visitor's email app. Replace the placeholder address with your real email.
- Icons are provided by `lucide-react`.
